// Language Switcher Component
// "use client" required for cookie interaction and state
// Sets NEXT_LOCALE cookie and reloads page to apply new language

"use client";

import { useState, useCallback } from "react";
import type { SupportedLocale } from "@/types";

/**
 * Supported locales with display labels
 */
const LOCALES: { code: SupportedLocale; label: string }[] = [
  { code: "en", label: "EN" },
  { code: "de", label: "DE" },
  { code: "fr", label: "FR" },
  { code: "es", label: "ES" },
  { code: "it", label: "IT" },
  { code: "zh", label: "中文" },
  { code: "ja", label: "日本語" },
  { code: "ko", label: "한국어" },
];

/**
 * Language switcher dropdown
 * Stores preference in NEXT_LOCALE cookie (GDPR session cookie)
 */
export default function LanguageSwitcher() {
  const [isOpen, setIsOpen] = useState(false);

  const handleSwitch = useCallback(async (locale: SupportedLocale) => {
    // Set cookie via server action or fetch
    try {
      await fetch("/api/i18n/set-locale", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale }),
      });
      // Reload page to apply new locale
      window.location.reload();
    } catch {
      console.error("Failed to switch language");
    }
  }, []);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex h-8 items-center gap-1 rounded-md border border-border px-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted"
        aria-label="Switch language"
        aria-expanded={isOpen}
      >
        <svg
          className="h-3.5 w-3.5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
          />
        </svg>
        <span>EN</span>
      </button>

      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          {/* Dropdown */}
          <div className="absolute right-0 z-50 mt-1 w-28 rounded-md border border-border bg-background py-1 shadow-lg">
            {LOCALES.map((locale) => (
              <button
                key={locale.code}
                type="button"
                onClick={() => handleSwitch(locale.code)}
                className="flex w-full items-center px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                {locale.label}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
