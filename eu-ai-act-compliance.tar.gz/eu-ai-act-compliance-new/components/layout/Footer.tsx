// Footer Component
// Server Component - contains GDPR/CCPA required links
// Links: Privacy Policy, Terms of Service, Cookie Policy, Contact

import Link from "next/link";

/**
 * Site footer with legal links and copyright
 * Required for GDPR/CCPA compliance
 */
export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full border-t border-border bg-muted/50">
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">AI Act Compliance</h3>
            <p className="text-sm text-muted-foreground">
              Comprehensive EU AI Act compliance platform for businesses worldwide.
            </p>
          </div>

          {/* Product */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">Product</h3>
            <ul className="space-y-2">
              <FooterLink href="/tools/risk-assessment">Risk Assessment</FooterLink>
              <FooterLink href="/tools/specialized-checks">Compliance Check</FooterLink>
              <FooterLink href="/tools/documentation">Documentation</FooterLink>
              <FooterLink href="/pricing">Pricing</FooterLink>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">Resources</h3>
            <ul className="space-y-2">
              <FooterLink href="/knowledge-base">AI Literacy Resources</FooterLink>
              <FooterLink href="/knowledge-base">EU AI Act Knowledge Base</FooterLink>
              <FooterLink href="/tools/risk-assessment">Risk Classification Guide</FooterLink>
              <FooterLink href="/knowledge-base">Blog</FooterLink>
            </ul>
          </div>

          {/* Legal - GDPR/CCPA required */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">Legal</h3>
            <ul className="space-y-2">
              <FooterLink href="/privacy">Privacy Policy</FooterLink>
              <FooterLink href="/terms">Terms of Service</FooterLink>
              <FooterLink href="/privacy#cookies">Cookie Policy</FooterLink>
              <FooterLink href="/privacy#data-rights">Your Data Rights</FooterLink>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {currentYear} AI Act Compliance Tool. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-xs text-muted-foreground">
              GDPR / CCPA / EU VAT Compliant
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

/**
 * Footer link with consistent styling
 */
function FooterLink({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <li>
      <Link
        href={href}
        className="text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        {children}
      </Link>
    </li>
  );
}
