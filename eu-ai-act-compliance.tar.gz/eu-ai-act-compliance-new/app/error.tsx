// Global Error Boundary
// Catches unhandled errors in Server Components
// Must be a Client Component with "use client"
// https://nextjs.org/docs/app/api-reference/file-conventions/error

"use client";

import { useEffect } from "react";
import Link from "next/link";

/**
 * Global error page
 * Props: error (the thrown error), reset (function to retry)
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log error to monitoring service (e.g., Sentry)
    console.error("[GLOBAL ERROR]", error);
  }, [error]);

  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
        <div className="space-y-6 text-center">
          {/* Error code */}
          <p className="text-8xl font-bold text-muted-foreground/30">500</p>

          {/* Message */}
          <h1 className="text-2xl font-bold tracking-tight">
            Something went wrong
          </h1>
          <p className="max-w-md text-sm text-muted-foreground">
            An unexpected error occurred. Our team has been notified. Please try
            again or navigate to a different page.
          </p>

          {/* Error digest for debugging */}
          {error.digest && (
            <p className="text-xs text-muted-foreground">
              Error ID: {error.digest}
            </p>
          )}

          {/* Actions */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={reset}
              className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Try Again
            </button>
            <Link
              href="/"
              className="inline-flex h-10 items-center justify-center rounded-md border border-border px-4 text-sm font-medium transition-colors hover:bg-muted"
            >
              Go Home
            </Link>
          </div>
        </div>
      </body>
    </html>
  );
}
