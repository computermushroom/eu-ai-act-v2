// Pricing Page
// Server Component - displays 5 subscription tiers
// Lemon Squeezy checkout integration will be wired in payment step

import type { Metadata } from "next";
import Link from "next/link";
import type { SubscriptionPlan } from "@/types";

export const metadata: Metadata = {
  title: "Pricing | EU AI Act Compliance Tool",
  description:
    "Choose the right plan for your EU AI Act compliance needs. From free risk assessment to enterprise-grade compliance automation.",
};

/**
 * Subscription plan definitions
 * Aligned with product specification: Free, Starter, Professional, Business, Enterprise
 */
const PLANS: SubscriptionPlan[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    features: [
      "AI Literacy Resources (Art.4)",
      "EU AI Act Knowledge Base / Article Search",
      "Art.6 Risk Classification Self-Assessment",
      "Multi-language Support (EN/DE/FR/ES/IT)",
      "URL Compliance Scan: 1x / month",
    ],
  },
  {
    id: "starter",
    name: "Starter",
    price: 39,
    features: [
      "Everything in Free",
      "Art.5 Prohibited AI Practices Check (8 items)",
      "Art.50 Transparency Obligations Check (5 items)",
      "URL Compliance Scan: 5x / month",
      "Basic Document Templates (3 sets)",
      "Compliance Score Report",
      "Risk Level Determination + Article Traceability",
      "Basic Industry Templates (Marketing / E-commerce / Customer Service)",
    ],
  },
  {
    id: "professional",
    name: "Professional",
    price: 89,
    features: [
      "Everything in Starter",
      "Art.9 Full Lifecycle Risk Management",
      "Art.10 Data Governance Assessment",
      "Annex IV High-Risk AI Technical Documentation",
      "Art.12/13/14/15 Specialized Compliance Checks",
      "Art.27 FRIA (Basic)",
      "URL Compliance Scan: 20x / month",
      "White-label PDF Reports",
      "Basic Audit Logs",
      "Multi-language Report Export",
      "Conformity Assessment Process Guidance",
    ],
  },
  {
    id: "business",
    name: "Business",
    price: 159,
    features: [
      "Everything in Professional",
      "Art.17 QMS Checklist",
      "Art.26 Deployer Obligations Tool",
      "Art.27+29 Full FRIA + Authority Notification",
      "Art.43/47/71/72/73 Compliance Tools",
      "Monthly Auto-Scan + Reports (up to 5 AI systems)",
      "Shadow AI Scan (Basic)",
      "Compliance Change Alerts",
      "Role-based Compliance Obligation Split",
      "Full Industry Templates (5 scenarios)",
      "Tamper-proof Audit Chain + Regulatory Evidence Package",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 249,
    features: [
      "Everything in Business",
      "Art.51-56 / Annex XI/XII GPAI Compliance",
      "Unlimited AI Systems",
      "Custom Industry Checklists",
      "Regulatory Change Push + Impact Analysis",
      "API / Webhook External Interfaces",
      "Team Collaboration (Roles / Tasks)",
      "GDPR Deep Integration Scan",
      "Document Version Management",
      "Dedicated Compliance Advisor Support",
      "White-label Customer Portal",
      "Shadow AI Scan (Full)",
      "Compliance Data Dashboard",
      "Embedded AI Compliance Assistant",
      "Employee Compliance Training Module",
    ],
  },
];

/**
 * Pricing page with 5 subscription tiers
 */
export default function PricingPage() {
  return (
    <div className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mx-auto max-w-2xl space-y-4 text-center">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
          Simple, transparent pricing
        </h1>
        <p className="text-lg text-muted-foreground">
          Choose the plan that fits your compliance needs. All prices include
          EU VAT. No hidden fees.
        </p>
      </div>

      {/* Pricing cards */}
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        {PLANS.map((plan) => (
          <PricingCard key={plan.id} plan={plan} />
        ))}
      </div>

      {/* FAQ / Notes */}
      <div className="mx-auto mt-16 max-w-3xl space-y-6 text-center">
        <p className="text-sm text-muted-foreground">
          All plans include GDPR/CCPA compliant data handling. You can cancel
          anytime. Questions?{" "}
          <Link href="/" className="text-primary hover:underline">
            Contact us
          </Link>
          .
        </p>
      </div>
    </div>
  );
}

/**
 * Individual pricing card component
 */
function PricingCard({ plan }: { plan: SubscriptionPlan }) {
  const isPopular = plan.id === "professional";

  return (
    <div
      className={`relative flex flex-col rounded-lg border p-6 shadow-sm ${
        isPopular
          ? "border-primary ring-1 ring-primary"
          : "border-border"
      }`}
    >
      {isPopular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
          Most Popular
        </div>
      )}

      <div className="space-y-2">
        <h3 className="text-lg font-semibold">{plan.name}</h3>
        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-bold">
            {plan.price === 0 ? "Free" : `€${plan.price}`}
          </span>
          {plan.price > 0 && (
            <span className="text-sm text-muted-foreground">/month</span>
          )}
        </div>
      </div>

      <ul className="mt-6 flex-1 space-y-3">
        {plan.features.map((feature, index) => (
          <li key={index} className="flex items-start gap-2 text-sm">
            <svg
              className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M5 13l4 4L19 7"
              />
            </svg>
            <span className="text-muted-foreground">{feature}</span>
          </li>
        ))}
      </ul>

      <div className="mt-6">
        {plan.price === 0 ? (
          <Link
            href="/register"
            className="inline-flex h-10 w-full items-center justify-center rounded-md border border-border bg-background px-4 text-sm font-medium transition-colors hover:bg-muted"
          >
            Get Started Free
          </Link>
        ) : (
          <button
            type="button"
            className={`inline-flex h-10 w-full items-center justify-center rounded-md px-4 text-sm font-medium transition-colors ${
              isPopular
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "border border-border bg-background hover:bg-muted"
            }`}
          >
            Subscribe
          </button>
        )}
      </div>
    </div>
  );
}
