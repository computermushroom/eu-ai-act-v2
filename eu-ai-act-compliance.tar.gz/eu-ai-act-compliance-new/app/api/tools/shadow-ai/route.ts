// Shadow AI Scan API
// POST: Scan an organization for unauthorized shadow AI tools

import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { scanShadowAI } from "@/lib/shadow-ai-scanner";
import { createAuditLog } from "@/lib/audit";

/**
 * POST /api/tools/shadow-ai
 * Scans an organization for shadow AI tool usage
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { organization, domain } = body as {
      organization?: string;
      domain?: string;
    };

    if (!organization || !organization.trim()) {
      return NextResponse.json(
        { error: "Organization name is required" },
        { status: 400 }
      );
    }

    // Run the shadow AI scan
    const result = await scanShadowAI(organization, domain);

    // Audit log
    await createAuditLog({
      userId: session.user.id,
      action: "tool_shadow_ai_scan",
      resource: "shadow-ai",
      details: {
        organization: result.organization,
        domain: result.domain,
        riskScore: result.riskScore,
        detectedCount: result.detectedTools.length,
      },
    });

    return NextResponse.json({ result });
  } catch (error) {
    console.error("[SHADOW AI SCAN] Error:", error);
    const message = error instanceof Error ? error.message : "Scan failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
