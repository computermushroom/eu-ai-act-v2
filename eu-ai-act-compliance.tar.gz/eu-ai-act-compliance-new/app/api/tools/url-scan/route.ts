// URL Scan API
// POST: Scan a URL for EU AI Act compliance indicators

import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { scanUrl } from "@/lib/url-scanner";
import { createAuditLog } from "@/lib/audit";

/**
 * POST /api/tools/url-scan
 * Scans a URL for AI compliance indicators
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { url } = body as { url?: string };

    if (!url) {
      return NextResponse.json(
        { error: "URL is required" },
        { status: 400 }
      );
    }

    // Basic URL validation
    try {
      new URL(url);
    } catch {
      return NextResponse.json(
        { error: "Invalid URL format" },
        { status: 400 }
      );
    }

    // Run the scan
    const result = await scanUrl(url);

    // Audit log
    await createAuditLog({
      userId: session.user.id,
      action: "tool_risk_assessment",
      resource: "url-scan",
      details: {
        url,
        score: result.overallScore,
        checksCount: result.checks.length,
      },
    });

    return NextResponse.json({ result });
  } catch (error) {
    console.error("[URL SCAN] Error:", error);
    const message = error instanceof Error ? error.message : "Scan failed";
    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
