// Tools API
// GET: Returns list of available compliance tools

import { NextResponse } from "next/server";

interface ToolInfo {
  id: string;
  title: string;
  description: string;
  articleRef: string;
  href: string;
  tier: string;
}

const TOOLS: ToolInfo[] = [
  {
    id: "risk-assessment",
    title: "Risk Classification",
    description: "Art.6 self-assessment for AI system risk levels (unacceptable, high, limited, minimal)",
    articleRef: "Art.6",
    href: "/tools/risk-assessment",
    tier: "free",
  },
  {
    id: "prohibited-practices",
    title: "Prohibited Practices",
    description: "Check your system against Art.5 banned AI practices",
    articleRef: "Art.5",
    href: "/tools/prohibited-practices",
    tier: "starter",
  },
  {
    id: "transparency",
    title: "Transparency Check",
    description: "Verify Art.50 transparency obligations for AI systems",
    articleRef: "Art.50",
    href: "/tools/transparency",
    tier: "starter",
  },
  {
    id: "url-scan",
    title: "URL Compliance Scan",
    description: "Scan any URL for AI compliance indicators, GDPR notices, and risk markers",
    articleRef: "General",
    href: "/tools/url-scan",
    tier: "free",
  },
];

/**
 * GET /api/tools
 * Returns available compliance tools
 */
export async function GET() {
  return NextResponse.json({ tools: TOOLS });
}
