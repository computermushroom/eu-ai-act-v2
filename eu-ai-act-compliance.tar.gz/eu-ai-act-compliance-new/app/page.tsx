// Home Page (Landing Page)
// Server Component with next-intl translations
// Converts visitors to registered users

import Link from "next/link";
import { getTranslations } from "next-intl/server";

/**
 * Feature card data for the landing page
 */
const FEATURES = [
  {
    title: "Risk Classification",
    description:
      "Self-assess your AI systems against EU AI Act Article 6 risk levels. Get instant classification with regulatory article references.",
    href: "/tools/risk-assessment",
  },
  {
    title: "Prohibited Practices Check",
    description:
      "Verify your AI systems against Article 5 prohibited practices. 8-point checklist with clear compliance guidance.",
    href: "/tools/prohibited-practices",
  },
  {
    title: "Transparency Obligations",
    description:
      "Ensure your AI systems meet Article 50 transparency requirements. 5-point verification with documentation templates.",
    href: "/tools/transparency",
  },
  {
    title: "Compliance Documentation",
    description:
      "Generate technical documentation, risk management reports, and conformity assessment packages aligned with Annex IV.",
    href: "/tools/documentation",
  },
  {
    title: "URL Compliance Scan",
    description:
      "Scan any public URL for AI compliance indicators. Identify potential risk factors and regulatory gaps automatically.",
    href: "/tools/url-scan",
  },
  {
    title: "Multi-language Reports",
    description:
      "Export compliance reports in English, German, French, Spanish, and Italian. Ready for regulatory submissions across the EU.",
    href: "/dashboard",
  },
];

/**
 * Landing page - converts visitors to users
 */
export default async function HomePage() {
  const t = await getTranslations();
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-muted/30 py-20 sm:py-32">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl space-y-8 text-center">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                {t("hero.title")}
              </h1>
              <p className="text-lg text-muted-foreground sm:text-xl">
                {t("hero.description")}
              </p>
            </div>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                href="/register"
                className="inline-flex h-11 items-center justify-center rounded-md bg-primary px-8 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
              >
                {t("hero.cta")}
              </Link>
              <Link
                href="/pricing"
                className="inline-flex h-11 items-center justify-center rounded-md border border-border bg-background px-8 text-sm font-medium transition-colors hover:bg-muted"
              >
                {t("hero.ctaSecondary")}
              </Link>
            </div>
            <p className="text-xs text-muted-foreground">
              {t("hero.note")}
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 sm:py-24">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl space-y-4 text-center">
            <h2 className="text-3xl font-bold tracking-tight">
              {t("features.title")}
            </h2>
            <p className="text-muted-foreground">
              {t("features.description")}
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* Compliance Articles Section */}
      <section className="border-t border-border bg-muted/30 py-16 sm:py-24">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl space-y-4 text-center">
            <h2 className="text-3xl font-bold tracking-tight">
              {t("articles.title")}
            </h2>
            <p className="text-muted-foreground">
              {t("articles.description")}
            </p>
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <ArticleCard
              article="Art. 5"
              title="Prohibited Practices"
              description="Social scoring, biometric identification, emotion recognition in workplace/education"
            />
            <ArticleCard
              article="Art. 6"
              title="Risk Classification"
              description="High-risk, limited-risk, minimal-risk categorization with clear criteria"
            />
            <ArticleCard
              article="Art. 9-15"
              title="High-Risk Requirements"
              description="Risk management, data governance, transparency, human oversight, accuracy"
            />
            <ArticleCard
              article="Art. 50"
              title="Transparency Obligations"
              description="Chatbot disclosure, deepfake labeling, emotion recognition notification"
            />
            <ArticleCard
              article="Art. 17"
              title="Quality Management"
              description="QMS establishment, documentation, post-market monitoring procedures"
            />
            <ArticleCard
              article="Art. 27"
              title="FRIA"
              description="Fundamental Rights Impact Assessment for high-risk AI systems"
            />
            <ArticleCard
              article="Annex IV"
              title="Technical Documentation"
              description="Complete technical documentation templates for high-risk AI systems"
            />
            <ArticleCard
              article="Art. 51-56"
              title="GPAI Compliance"
              description="General-purpose AI model obligations, systemic risk evaluation"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl space-y-6 text-center">
            <h2 className="text-3xl font-bold tracking-tight">
              {t("hero.title").replace("Navigate", "Start your compliance journey today")}
            </h2>
            <p className="text-muted-foreground">
              {t("hero.description").split(".")[0]}. Join businesses across Europe using our platform to navigate EU AI Act requirements. Free plan available — no credit card required.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                href="/register"
                className="inline-flex h-11 items-center justify-center rounded-md bg-primary px-8 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Create Free Account
              </Link>
              <Link
                href="/pricing"
                className="inline-flex h-11 items-center justify-center rounded-md border border-border bg-background px-8 text-sm font-medium transition-colors hover:bg-muted"
              >
                Compare Plans
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/**
 * Feature card for the landing page
 */
function FeatureCard({
  title,
  description,
  href,
}: {
  title: string;
  description: string;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="group flex flex-col rounded-lg border border-border bg-background p-6 shadow-sm transition-colors hover:border-primary/50 hover:bg-muted/50"
    >
      <h3 className="text-lg font-semibold group-hover:text-primary">
        {title}
      </h3>
      <p className="mt-2 flex-1 text-sm text-muted-foreground">
        {description}
      </p>
      <span className="mt-4 inline-flex items-center text-sm font-medium text-primary">
        Learn more
        <svg
          className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M9 5l7 7-7 7"
          />
        </svg>
      </span>
    </Link>
  );
}

/**
 * Article coverage card
 */
function ArticleCard({
  article,
  title,
  description,
}: {
  article: string;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-background p-5">
      <div className="flex items-center gap-2">
        <span className="rounded bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
          {article}
        </span>
      </div>
      <h3 className="mt-3 text-sm font-semibold">{title}</h3>
      <p className="mt-1 text-xs text-muted-foreground">{description}</p>
    </div>
  );
}
